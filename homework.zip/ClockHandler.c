#include "CLockHandler.h"

/*Section: Local variables*/
static sTimeDef v_Time;
static sDateDef v_Date;
/*End Section*/

/*Section: Function implementation*/
void CH_Init()
{
}

void CH_RunOne()
{
}
/*End section*/