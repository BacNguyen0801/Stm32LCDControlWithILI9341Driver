#ifndef __CLOCK_HANDLER_h__
#define __CLOCK_HANDLER_h__

void CH_Init();
void CH_RunOne();

#endif //__CLOCK_HANDLER_h__